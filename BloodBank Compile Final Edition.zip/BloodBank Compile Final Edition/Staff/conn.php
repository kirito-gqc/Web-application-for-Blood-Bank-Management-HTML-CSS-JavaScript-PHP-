<?php

 

    $con = mysqli_connect("localhost","root","","bloodbanksys","3306");
    
    if(mysqli_connect_errno())
    {
        echo "Failed to connect MySQL:".mysqli_connect_error();
    }
    
?>