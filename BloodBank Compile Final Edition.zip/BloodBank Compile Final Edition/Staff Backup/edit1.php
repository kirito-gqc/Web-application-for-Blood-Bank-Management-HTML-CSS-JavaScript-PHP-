<?php

include('config.php');

if (isset($_POST['submit']))
{
$id=$_POST['id'];
$bloodid=mysqli_real_escape_string($db, $_POST['BloodID']);
$result=mysqli_real_escape_string($db, $_POST['Result']);

mysqli_query($db,"UPDATE test SET BloodID='$bloodid', Result='$result' WHERE TestID='$id'");

header("Location:bloodtest.php");
}


if (isset($_GET['id']) && is_numeric($_GET['id']) && $_GET['id'] > 0)
{

$id = $_GET['id'];
$result = mysqli_query($db,"SELECT * FROM test WHERE TestID=".$_GET['id']);

$row = mysqli_fetch_array($result);

if($row)
{

$id = $row['TestID'];
$bloodid= $row['BloodID'];
$result = $row['Result'];
}
else
{
echo "No results!";
}
}
?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title>Staff | Edit Blood Test</title>
</head>
<body>



<form action="" method="post" action="edit1.php">
<input type="hidden" name="id" value="<?php echo $id; ?>"/>

<table border="1">
<tr>
<td colspan="2"><b><font color='Red'>Edit Records </font></b></td>
</tr>
<tr>
<td width="179"><b><font >BloodID<em>*</em></font></b></td>
<td><label>
<input type="text" name="product_name" value="<?php echo $bloodid ?>" />
</label></td>
</tr>

<tr>
<td width="179"><b><font color='#663300'>Result<em>*</em></font></b></td>
<td><label>
<input type="text" name="price" value="<?php echo $result ?>" />
</label></td>
</tr>


<tr align="Right">
<td colspan="2"><label>
<input type="submit" name="submit" value="Edit Records">
</label></td>
</tr>
</table>
</form>
</body>
</html>
